package com.example.service;

import java.util.List;

import com.example.entity.*;
public interface CustomerService {


	Customer addresscreation(Customer addr);

	List<Customer> getAlladdress();

	Customer updateaddr(Customer addr);

	Customer deleteaddrByID(int addr_id);

    Customer aiccreation(Customer prod);

    List<Customer> getAllproducts();

	}
