package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entity.Customer;
import com.example.dao.CustomerDaoImpl;
import com.example.entity.*;
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService 
{
@Autowired
CustomerDaoImpl dao;

@Override
public Customer addresscreation(Customer addr) {
	return dao.addresscreation(addr);
}


@Override

public List<Customer> getAlladdress() 
{
return dao.getAlladdress();
}



@Override
public Customer updateaddr(Customer addr) {
	return dao.updateaddr(addr);	
}


@Override
public Customer deleteaddrByID(int addr_id) 
{
	return dao.deleteaddrByID(addr_id);
}

@Override
public Customer aiccreation(Customer prod) {
	return dao.aiccreation(prod);
}

public List<Customer> getAllproducts() 
{
return dao.getAlladdress();
}

}