package com.example.dao;

import java.util.List;

import com.example.entity.*;
public interface CustomerDao {

	Customer addresscreation(Customer addr);

	List<Customer> getAlladdress();

	Customer updateaddr(Customer addr);

	Customer deleteaddrByID(int addr_id);
	
	Customer aiccreation(Customer prod);
	
	List<Customer> getAllproducts();

}
