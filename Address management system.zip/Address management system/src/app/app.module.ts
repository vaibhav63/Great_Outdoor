import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddresscreationComponent } from './addresscreation/addresscreation.component';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import { UpdateaddrComponent } from './updateaddr/updateaddr.component';
import { DeleteaddrComponent } from './deleteaddr/deleteaddr.component';

@NgModule({
  declarations: [
    AppComponent,
    AddresscreationComponent,
    UpdateaddrComponent,
    DeleteaddrComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
