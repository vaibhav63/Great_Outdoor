import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddresscreationComponent } from './addresscreation/addresscreation.component';
import { DeleteaddrComponent } from './deleteaddr/deleteaddr.component';
import { UpdateaddrComponent } from './updateaddr/updateaddr.component';

const routes: Routes = [
  {path:'app-addresscreation',component:AddresscreationComponent},
  {path:'app-deleteaddr',component:DeleteaddrComponent},
  {path:'app-updateaddr',component:UpdateaddrComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  
 }
