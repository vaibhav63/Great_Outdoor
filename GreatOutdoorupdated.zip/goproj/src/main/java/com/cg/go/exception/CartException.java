package com.cg.go.exception;

public class CartException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public CartException(String msg) {
		super(msg);
	}
}
