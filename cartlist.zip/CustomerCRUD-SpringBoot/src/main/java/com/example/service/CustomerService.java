package com.example.service;

import java.util.List;

import com.example.entity.*;
public interface CustomerService {


    Customer aiccreation(Customer prod);

    List<Customer> getAllproducts();

	}
