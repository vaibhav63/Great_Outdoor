package com.example.dao;

import java.util.List;

import com.example.entity.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.example.entity.Customer;
@Repository
public class CustomerDaoImpl implements CustomerDao {

	@PersistenceContext	
	 EntityManager em;
	
	
	@Override
	public Customer aiccreation(Customer addr) {
		// TODO Auto-generated method stub
		Customer e=em.merge(addr);
		return e;
	}


        @Override
	public List<Customer> getAllproducts() {
		Query q=em.createQuery("select m from Customer m");
		List<Customer> prodlist=q.getResultList();
		return prodlist;
	}


}
