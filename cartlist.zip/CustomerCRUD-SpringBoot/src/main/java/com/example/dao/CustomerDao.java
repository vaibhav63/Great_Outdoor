package com.example.dao;

import java.util.List;

import com.example.entity.*;
public interface CustomerDao {
	
	Customer aiccreation(Customer prod);
	
	List<Customer> getAllproducts();

}
