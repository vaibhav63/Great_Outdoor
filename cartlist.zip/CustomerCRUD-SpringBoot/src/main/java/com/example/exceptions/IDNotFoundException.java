package com.example.exceptions;

public class IDNotFoundException extends RuntimeException{
    public IDNotFoundException(String msg){
        super(msg);
    }

    public IDNotFoundException(String msg,Throwable e){
        super(msg,e);
    }
}
