import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'  
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AdminoperationsComponent } from './adminoperations/adminoperations.component';
import { CustomeroperationsComponent } from './customeroperations/customeroperations.component';
import { LogoutComponent } from './logout/logout.component';
const routes: Routes = [
  {path:'app-login',component:LoginComponent},
  {path:'app-signup',component:SignupComponent},
  {path:'app-adminoperations',component:AdminoperationsComponent},
  {path:'app-customeroperations',component:CustomeroperationsComponent},
  {path:'app-logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
  FormsModule,  
  ReactiveFormsModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }

